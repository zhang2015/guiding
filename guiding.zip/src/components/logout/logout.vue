<template>
  <div class="tab_type_box">
    <div class="tab_type_head">
      <a class="active">注销账号</a>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {}
</script>

<style media="screen">

</style>
