<template>
   <router-view></router-view>
</template>

<script type="text/ecmascript-6">
export default {
    data() {
        return {
            
        }
    },
    methods: {
        
    }
}
</script>

<style media="screen">
    .cart_head{
        display: flex;
        width: 100%;
        height: 65px;
        justify-content: space-between;
        align-items: center;
    }
    .cart_title{
        font-size: 18px;
        font-weight: bold;
        color: #616161;
    }
    .cart_plan img{
        padding-left: 8px;
    }
</style>