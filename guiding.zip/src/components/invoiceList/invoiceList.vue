<template>
  <div>
    <invoiceListPersonal></invoiceListPersonal>
  </div>
</template>

<script type="text/ecmascript-6">
  import invoiceListPersonal from '../invoiceListPersonal/invoiceListPersonal'
  export default {
    components:{
      invoiceListPersonal
    }
  }
</script>

<style media="screen">
  
</style>
