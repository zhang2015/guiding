<template>
  <div class="collect_list">
    <section>
      <img src="http://file.hmting.com/data/attachment/forum/201411/08/174731xxymzkxkmvnok13z.jpg">
      <div>
        <a>四川贵鼎知识产权评估服务有限公司</a>
        <span>取消收藏</span>
      </div>
    </section>
    <section>
      <img src="http://file.hmting.com/data/attachment/forum/201411/08/174731xxymzkxkmvnok13z.jpg">
      <div>
        <a>四川贵鼎知识产权评估服务有限公司</a>
        <span>取消收藏</span>
      </div>
    </section>
    <section>
      <img src="http://file.hmting.com/data/attachment/forum/201411/08/174731xxymzkxkmvnok13z.jpg">
      <div>
        <a>四川贵鼎知识产权评估服务有限公司</a>
        <span>取消收藏</span>
      </div>
    </section>
    <section>
      <img src="http://file.hmting.com/data/attachment/forum/201411/08/174731xxymzkxkmvnok13z.jpg">
      <div>
        <a>四川贵鼎知识产权评估服务有限公司</a>
        <span>取消收藏</span>
      </div>
    </section>
    <section>
      <img src="http://file.hmting.com/data/attachment/forum/201411/08/174731xxymzkxkmvnok13z.jpg">
      <div>
        <a>四川贵鼎知识产权评估服务有限公司</a>
        <span>取消收藏</span>
      </div>
    </section>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {}
</script>

<style media="screen">
  .collect_list{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between; 
  }
  .collect_list section{
    display: flex;
    width: 450px;
    height: 90px;
    margin-bottom: 20px;
    justify-content: flex-start;
    align-items: center;
    border: 1px solid #e5e7ed;
    background: #f9fafc;
  }
  .collect_list section img{
    width: 60px;
    height: 60px;
    padding: 20px;
  }
  .collect_list section div{
    display: flex;
    flex-direction: column;
    flex-flow: 1;
  }
  .collect_list section div a{
    font-size: 16px;
    line-height: 32px;
    color: #616161;
  }
  .collect_list section div span{
    font-size: 14px;
    line-height: 22px;
    color: #898989;
    cursor: pointer;
  }
</style>
