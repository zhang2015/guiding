<template>
  <div class="news main_content clearfix">
    <div class="main_content_left">
      <div class="tab_type_box">
        <div class="tab_type_head">
          <a class="active">关于我们</a>
        </div>
        <div class="news_list">

        </div>
      </div>
    </div>
    <div class="main_content_right">

    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {}
</script>

<style media="screen">

</style>
