<template>
  <div class="padding20">
    <orderFormList></orderFormList>
  </div>
</template>

<script type="text/ecmascript-6">
  import orderFormList from '../orderFormList/orderFormList'

  export default {
    components:{
      orderFormList
    }
  }
</script>

<style media="screen">
  
</style>
