<template>
  <div>
    <invoiceListCommon></invoiceListCommon>
  </div>
</template>

<script type="text/ecmascript-6">
  import invoiceListCommon from '../invoiceListCommon/invoiceListCommon'
  export default {
    components:{
      invoiceListCommon
    }
  }
</script>

<style media="screen">
  
</style>
