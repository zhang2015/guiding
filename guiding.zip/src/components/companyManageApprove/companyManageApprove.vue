<template>
  <div class="tab_type_box">
    <div class="tab_type_head">
      <a class="active">认证管理</a>
    </div>
    <div class="padding20">
      <router-view></router-view>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {}
</script>

<style media="screen">

</style>
