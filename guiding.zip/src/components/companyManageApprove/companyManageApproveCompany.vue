<template>
  <div>
      <ul class="manage_list_common setting_list">
        <li>
          <p>营业执照类型</p>
          <span class="submit_btn company_submit">普通</span>
          <span class="cancel_btn invoice_cancel_btn">三证合一</span>
        </li>
        <li class="upload">
          <p>企业营业执照</p>
          <img src="../../assets/uploadimg.png">
        </li>
        <li class="upload">
          <p>组织机构代码证</p>
          <img src="../../assets/uploadimg.png">
        </li>
        <li class="upload">
          <p>税务登记代码证</p>
          <img src="../../assets/uploadimg.png">
        </li>
        <li>
          <p></p>
          <span class="submit_btn company_submit">提交</span>
          <span class="cancel_btn invoice_cancel_btn">取消</span>
        </li>
      </ul>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {}
</script>

<style media="screen">

</style>
