<template>
  <div>
    <collectlist></collectlist>
  </div>
</template>

<script type="text/ecmascript-6">
  import collectlist from '../CollectList/CollectList'

  export default {
    components:{
      collectlist
    }
  }
</script>

<style media="screen">

</style>
