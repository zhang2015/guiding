<template>
  <div class="tab_type_box">
    <div class="tab_type_head">
      <a class="active">邮寄发票</a>
    </div>
    <div class="padding20">
      邮寄发票
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {}
</script>

<style media="screen">

</style>
